#!/usr/bin/python
print("hello world!")
print("hello python language")
print("I like typing this.")
print("This is fun")
print("python is fun language.")


#!/usr/bin/python

#Exercise 2

# A comment, is used for reading your program later.

# Anthing after a # is ignored by the python interpretor

print("this code will be accepted by python.") # and the comment will be ignored

# print("This code will not run.")

print("this code will run.")
